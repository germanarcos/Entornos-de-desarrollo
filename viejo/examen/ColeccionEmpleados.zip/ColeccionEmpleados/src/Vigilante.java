import java.io.Serializable;

public class Vigilante extends Empleado implements Serializable, Comparable<Empleado> {
	private double plusPeligrosidad;
	
	public Vigilante(String nombre, String apellido, String dni) {
		super(nombre, apellido, dni);
		plusPeligrosidad = 3000;
	}

	
	public double getPlusPeligrosidad() {
		return plusPeligrosidad;
	}


	public void setPlusPeligrosidad(double plusPeligrosidad) {
		this.plusPeligrosidad = plusPeligrosidad;
	}


	public double calculaIngresos(){
		return super.getSalario() + plusPeligrosidad;
	}
	
	public boolean equals(Vigilante o) {
		// TODO Auto-generated method stub
		return super.getDni().equals(o.getDni());
	}
	
	public int compareTo(Vigilante o) {
		// TODO Auto-generated method stub
		return getDni().compareTo(o.getDni());
	}
	public String toString(){
		String cadena = super.toString() + ". Gana " + calculaIngresos() + "� anuales incluido el plus"
				+ "\nAdemas es vigilante con plus de peligrosidad de " + plusPeligrosidad + " �";
		return cadena;
	}
}
