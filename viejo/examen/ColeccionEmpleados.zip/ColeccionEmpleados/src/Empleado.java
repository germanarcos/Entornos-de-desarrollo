import java.io.Serializable;

/**
 * @author usuario
 *
 */
public abstract class Empleado implements Serializable, Comparable<Empleado> {
	private String nombre;
	private String apellido;
	private String dni;
	private int horasPorSemana; // numero de horas de trabajo a la semana
	private double salario;
	private int diasVacaciones;


	public Empleado(String nombre, String apellido, String dni) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
		salario = 20000;
		horasPorSemana=40;
		diasVacaciones=15;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public int getHorasPorSemana() {
		return horasPorSemana;   
	}
	
	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public int getDiasVacaciones() {
		return diasVacaciones;
	}

	public void setDiasVacaciones(int diasVacaciones) {
		this.diasVacaciones = diasVacaciones;
	}

	public abstract double calculaIngresos();
	
	public boolean equals(Empleado o) {
		// TODO Auto-generated method stub
		return this.dni.equals(o.dni);
	}
	
	public int compareTo(Empleado o) {
		// TODO Auto-generated method stub
		return this.dni.compareTo(o.dni);
	}
	public String toString(){
		String cadena= nombre + " " + apellido + " " + dni + 
				      "\ntrabaja " + horasPorSemana + " horas semanales"
				      + " y tiene " + diasVacaciones + " dias de vacaciones";
		return cadena;
	}
	
}// Empleado
