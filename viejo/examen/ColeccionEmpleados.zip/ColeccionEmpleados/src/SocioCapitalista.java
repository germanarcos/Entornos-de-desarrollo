import java.io.Serializable;

public class SocioCapitalista extends Empleado implements Serializable, Comparable<Empleado> {
	private double capitalAportado;

	public SocioCapitalista(String nombre, String apellido, String dni, double capitalAportado) {
		super(nombre, apellido, dni);
		setDiasVacaciones(0);
		this.capitalAportado = capitalAportado;
	}
	
	public double calculaIngresos(){
		return super.getSalario() + 5000;
	}
	
	public boolean equals(SocioCapitalista o) {
		// TODO Auto-generated method stub
		return super.getDni().equals(o.getDni());
	}
	
	public int compareTo(SocioCapitalista o) {
		// TODO Auto-generated method stub
		return getDni().compareTo(o.getDni());
	}
	public String toString(){
		String cadena = super.toString() + ". Gana " + calculaIngresos() + "� anuales" 
				+ "\nAdemas es socio capitalista con un capital de " + capitalAportado + " �";
		return cadena;
	}
}
