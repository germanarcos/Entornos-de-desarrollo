import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Principal {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws ClassNotFoundException{
		int op, numEmpleado=0, index;
		double cantidad;
		List<Empleado> coleccion = new LinkedList<Empleado>();
		Fichero fichero = new Fichero("empleados.dat");
		if (fichero.esFichero()) {
			coleccion=(List<Empleado>)fichero.cargaFichEntr();
		} 

		do {
			if(coleccion.size()==0){
				op = menu("\n1 Crear Empleados" 
						+ "\n0 Salir",1);
			}else{
				op = menu("\n1 Crear Empleados" 
						+ "\n2 Listar datos de los empleados" 
						+ "\n3 Modificar datos de un empleado"
						+ "\n4 Asignar ventas a un vendedor"
						+ "\n5 Ver total a pagar en concepto de sueldos" 
						+ "\n0 Salir", 5);
			}
			switch (op) {
			case 1://Crear Empleados
				crearEmpleados(coleccion);
				fichero.escribeFichSal(coleccion);
				break;
			case 2://Listar datos de los empleados
				if(coleccion.size()!=0){
					index=0;
					for(Empleado e: coleccion){
						index++;
						System.out.println(index + ".- " + e);
						System.out.println("--------------------------------------------------\n");
					}
				}else{
					System.out.println("No hay empleados");
				}
				break;
			case 3://Modificar datos de un empleado
				System.out.println("Modificar datos de los empleados");
				System.out.println("--------------------------------");

				if(coleccion.size()!=0){
					do{
						index=0; // en pantalla vemos los numeros de empleado a paratir de 1
						for(Empleado e: coleccion){
							index++;
							System.out.println(index + ".- " + e);
							System.out.println("--------------------------------------------------\n");
						}
						do{
							numEmpleado = Leer.pedirEntero("�Numero de empleado a modificar?(0:fin)");
						}while (numEmpleado<0 || numEmpleado >coleccion.size());
						if(numEmpleado!=0){
							modificaEmpleado(coleccion, (numEmpleado-1)); // el indice del elemento en la coleccion es 1 menos
							fichero.escribeFichSal(coleccion);
						}
					} while (numEmpleado !=0);
				}else{
					System.out.println("\nNo hay empleados");
				}
				break;
			case 4://Asignar ventas a un vendedor

				if(coleccion.size()!=0){
					do {
						index=0;// en pantalla vemos los numeros de empleado a paratir de 1
						for(Empleado e: coleccion){
							index++;
							if(e instanceof Vendedor){
								System.out.println(index + ".- " + e);
								System.out.println("--------------------------------------------------\n");
							}
						}
						do{
							numEmpleado = Leer.pedirEntero("�Numero de vendedor a asignar venta?(0:fin)");
						}while (numEmpleado<0 || numEmpleado >coleccion.size());
						if(numEmpleado!=0){
							if(coleccion.get(numEmpleado-1)instanceof Vendedor){// el indice del elemento en la coleccion es 1 menos
								cantidad=Leer.pedirDecimal("Valor de la venta?");
								//La lista tiene objetos de clase Empleado. Hay que hacer casting a Vendedor 
								Vendedor unVendedor = (Vendedor)coleccion.get(numEmpleado-1);
								unVendedor.vender(cantidad); ///modificamos las ventas del vendedor 
								coleccion.set(numEmpleado-1, unVendedor); // actualizamos la coleccion
								fichero.escribeFichSal(coleccion);////// actualizar fichero
							}
						}
					} while (numEmpleado !=0);
				}else{
					System.out.println("\nNo hay empleados");
				}
				break;
			case 5://Ver total a pagar en concepto de sueldos
				System.out.println("Los sueldos de todos los empleados son: " + totalSueldos(coleccion));
				break;
			default:
				if (op != 0)
					System.out.println("Opcion incorrecta");
			}
		} while (op != 0);
	}// main

	///////////////////////////////////////////////////////////// menu
	private static int menu(String cadenaOpciones, int numOpciones) {
		int op;
		do {
			System.out.println(cadenaOpciones);
			op = Leer.pedirEntero("\nElija opcion");
		} while (op < 0 || op > numOpciones);
		return op;
	}// /////////////////////////////////////////////////////////// menu
	// /////////////////////////////////////////////////////////// crearEmpleados
	private static void crearEmpleados(List<Empleado> coleccion) {
		// tendr� 2 socios capitalistas, 3 vendedores y 2 vigilantes
		String vecNombres[] = { "Pilar", "Jose", "Enrique", "Ana", "Luis", "Alicia", "Maria", "Andrea", "Roberto",
				"Rafael", "Pablo", "Juan", "Jorge", "Alberto" };
		String vecApellidos[] = { "Mendez", "Martinez", "Soria", "Sanchez", "Santolaria", "Perez", "Gutierrez",
				"Canales", "Montes", "Rios", "Ochoa", "Calvo", "Lopez", "Rodriguez" };

		String dni, nombre, apellido;
		double capital;
		// considero que al crear empleados quiero partir de cero y borrar la colecci�n que tuviera hasta ahora
		// si omito la siguiente l�nea se a�adirian los elementos que se crean a los que ya hubiera en la coleccion
		coleccion.clear();
		int k, i;
		for (k = 1; k <= 2; k++) {// creamos 2 socios capitalistas
			i = (int) Math.floor(Math.random() * vecNombres.length);
			nombre = vecNombres[i];
			apellido = vecApellidos[(int) Math.floor(Math.random() * vecApellidos.length)];
			do {
				dni = generarDNI();
			} while (dniRepetido(dni, coleccion)); // no se puede repetir el
			// dni
			capital = (Math.random() * (3000 - 3500) + 1500);
			coleccion.add(new SocioCapitalista(nombre, apellido, dni, capital));
		}

		for (k = 1; k <= 3; k++) {// creamos 3 vendedores
			i = (int) Math.floor(Math.random() * vecNombres.length);
			nombre = vecNombres[i];
			apellido = vecApellidos[(int) Math.floor(Math.random() * vecApellidos.length)];
			do {
				dni = generarDNI();
			} while (dniRepetido(dni, coleccion)); // no se puede repetir el
			// dni
			coleccion.add(new Vendedor(nombre, apellido, dni));
		}

		for (k = 1; k <= 2; k++) {// creamos 2 vigilantes
			i = (int) Math.floor(Math.random() * vecNombres.length);
			nombre = vecNombres[i];
			apellido = vecApellidos[(int) Math.floor(Math.random() * vecApellidos.length)];
			do {
				dni = generarDNI();
			} while (dniRepetido(dni, coleccion)); // no se puede repetir el dni
			coleccion.add(new Vigilante(nombre, apellido, dni));
		}
	}// /////////////////////////////////////////////////////////// crearEmpleados

	///////////////////////////////////////////////////////////// generarDNI
	private static String generarDNI() {
		final String CONTROL = "TRWAGMYFPDXBNJZSQVHLCKE";
		String dni = "";
		char letra;
		int k, numero;
		for (k = 1; k <= 8; k++) {
			dni = dni + (int) Math.floor(Math.random() * 10);
		}
		numero = Integer.parseInt(dni);
		letra = CONTROL.charAt(numero % 23);
		dni = dni + letra;
		return dni;
	}///////////////////////////////////////////////////////////// generarDNI

	///////////////////////////////////////////////////////////// dniRepetido
	private static boolean dniRepetido(String dni, List<Empleado> coleccion) {
		boolean repetido = false;


		if (coleccion.contains(dni)) {
			repetido = true;
		}

		return repetido;
	}///////////////////////////////////////////////////////////// dniRepetido

	///////////////////////////////////////////////////////////// dniCorrecto
	private static boolean dniCorrecto(String dni) {
		final String CONTROL = "TRWAGMYFPDXBNJZSQVHLCKE";
		boolean correcto = false;
		String cadNumeros = dni.substring(0, dni.length()-1);
		char letra=dni.charAt(dni.length()-1);
		int numero;

		numero = Integer.parseInt(cadNumeros);
		if(letra == CONTROL.charAt(numero % 23))
			correcto = true;
		return correcto;
	}///////////////////////////////////////////////////////////// dniCorrecto

	///////////////////////////////////////////////////////////// modificaEmpleado

	private static void modificaEmpleado(List<Empleado> coleccion, int cual){//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		int op;
		String nombre, apellido, dniNuevo;
		double salario;
		Empleado unEmpleado=null;
		boolean encontrado=false;
		unEmpleado=coleccion.get(cual);

		do{
			System.out.println("Modificacion de datos de empleados. Indicar el campo a modificar:");
			op=menu("\n1 Nombre"
					+ "\n2 Apellido"
					+ "\n3 dni"
					+ "\n4 salario"
					+ "\n0 Salir", 4);
			switch (op){
			case 1:
				nombre=Leer.pedirCadena("�Nuevo nombre?");
				unEmpleado.setNombre(nombre);
				break;
			case 2:
				apellido=Leer.pedirCadena("�Nuevo apellido?");
				unEmpleado.setApellido(apellido);
				break;
			case 3:
				do{
					dniNuevo=Leer.pedirCadena("�Nuevo dni?");
				}while(dniRepetido(dniNuevo, coleccion) || !dniCorrecto(dniNuevo));
				unEmpleado.setDni(dniNuevo);
				break;
			case 4:
				salario=Leer.pedirDecimal("�Nuevo salario");
				unEmpleado.setSalario(salario);
				break;
			default:
				if(op!=0)
					System.out.println("Opcion incorrecta");
			}
		}while(op!=0);
	}///////////////////////////////////////////////////////////// modificaEmpleado

	///////////////////////////////////////////////////////////// totalSueldos
	private static double totalSueldos(List<Empleado> coleccion) {
		double total = 0;
		for(Empleado e: coleccion){
			total = total + e.calculaIngresos();
		}
		return total;
	} ///////////////////////////////////////////////////////////// totalSueldos
}// class