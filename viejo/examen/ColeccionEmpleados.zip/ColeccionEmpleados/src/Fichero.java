import java.io.*;


public class Fichero {
	private File nombre;

	/**
	 * @param nombre
	 */
	public Fichero(String nombre) {
		this.nombre= new File(nombre);
	}
		
/*	public Fichero() {
		this.nombre= null;
	}*/
	
	public boolean esFichero(){
		if (nombre.exists() && nombre.isFile()) {
            return true;
        } else {
            return false;
        }
	}
	
	public void escribeFichSal(Object coleccion){
		ObjectOutputStream fichEscribir=null;

		boolean existe=true;
		try{
			fichEscribir = new ObjectOutputStream(new FileOutputStream(this.nombre));
			fichEscribir.writeObject(coleccion);

		}catch(FileNotFoundException ex){
			System.out.println("el fichero no existe: " + ex.getMessage());
			existe=false;
		} catch (IOException ex) {
			System.out.println("Error E/S: " + ex.getMessage());
		} finally {
			try {
				if(existe){
					fichEscribir.close();					
				}
			} catch (IOException ex) {
				System.out.println("Error al cerrar fichero: " + ex.getMessage());
			}
		}
	}
	
	public Object cargaFichEntr() throws ClassNotFoundException{
		ObjectInputStream fichLeer=null;
		Object coleccion = new Object();
		boolean existe=true;
		try{
			fichLeer = new ObjectInputStream(new FileInputStream(this.nombre));
			try {
				coleccion = (Object) fichLeer.readObject();

			} catch (EOFException e) {
				System.out.println("Error en fichero");//Salimos del bucle porque ya hemos recorrido el fichero entero
			}


		}catch(FileNotFoundException ex){
			System.out.println("el fichero no existe: " + ex.getMessage());
			existe=false;
		} catch (IOException ex) {
			System.out.println("Error E/S: " + ex.getMessage());
		} finally {
			try {
				if(existe){
					fichLeer.close();
				}
			} catch (IOException ex) {
				System.out.println("Error al cerrar fichero: " + ex.getMessage());
			}
		}
		return coleccion;
	}	
}
