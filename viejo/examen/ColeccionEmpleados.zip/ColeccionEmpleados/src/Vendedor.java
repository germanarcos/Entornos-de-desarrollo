import java.io.Serializable;

public class Vendedor extends Empleado implements Serializable, Comparable<Empleado> {
	private double ventasRealizadas;
	private double comisionACobrar;
	
	public Vendedor(String nombre, String apellido, String dni) {
		super(nombre, apellido, dni);
		setDiasVacaciones(getDiasVacaciones()+5);
		ventasRealizadas = 0;
		comisionACobrar=0;
	}

	public void vender(double cantidad){
		ventasRealizadas = ventasRealizadas + cantidad;
	}

	public void anularVenta(double cantidad){
		ventasRealizadas = ventasRealizadas - cantidad;
	}
	
	public void calcularComision(){
		comisionACobrar=ventasRealizadas*0.01;
	}
	public double calculaIngresos(){
		calcularComision();
		return super.getSalario() + comisionACobrar;
	}
	public boolean equals(Vendedor o) {
		// TODO Auto-generated method stub
		return super.getDni().equals(o.getDni());
	}
	
	public int compareTo(Vendedor o) {
		// TODO Auto-generated method stub
		return getDni().compareTo(o.getDni());
	}
	public String toString(){
		String cadena = super.toString() + ". Gana " + calculaIngresos() + "� anuales incluida comision"
				+ "\nAdemas es vendedor con ventas por valor de " + ventasRealizadas + " �"
				+ "\nSu comision ha sido: " + comisionACobrar + "�";
		return cadena;
	}
}
